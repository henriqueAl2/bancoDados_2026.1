from sqlalchemy import Column, Integer, String, ForeignKey, Date, DateTime, LargeBinary
from database import Base
from sqlalchemy.orm import relationship 

class Curso(Base):
    __tablename__ = "Curso"
    idCurso = Column(Integer, primary_key=True, autoincrement=True)
    nome = Column(String(255))
    centro_academico = Column(String(45))
    atletica = Column(String(45))
    departamento_responsalvel = Column(String(255))
    sigla = Column(String(45))

class Pessoa(Base):
    __tablename__ = "Pessoa"

    cpf = Column(String(11), primary_key=True)
    nome = Column(String(255), nullable=True)
    email = Column(String(255), nullable=True)
    telefone = Column(String(45), nullable=True)
    data_nasc = Column(Date, nullable=True)
    
    # Conforme seu SQL: VARCHAR(6) e NOT NULL
    senha = Column(String(6), nullable=False) 
    
    # Chave Estrangeira para Curso
    Curso_idCurso = Column(Integer, ForeignKey("Curso.idCurso"), nullable=False)
    curso = relationship("Curso")


class Inscricao(Base):
    __tablename__ = "Inscrição"
    numero = Column(Integer, primary_key=True, autoincrement=True)
    data = Column(Date)
    status = Column(String(45))
    Pessoa_cpf = Column(String(11), nullable=False)
    Evento_codEvento = Column(Integer, nullable=False)

class Feedback(Base):
    __tablename__ = "Feedback"
    idFeedback = Column(Integer, primary_key=True, autoincrement=True)
    comentario = Column(String(255))
    data_feedback = Column(Date)
    Inscrição_numero = Column(Integer, nullable=False)

class Local(Base):
    __tablename__ = "Local"
    idLocal = Column(Integer, primary_key=True, autoincrement=True)
    acessivel = Column(Integer)
    predio = Column(String(255))
    sala = Column(String(45))
    Feedback_idFeedback = Column(Integer, nullable=False)

class Coletivo(Base):
    __tablename__ = "Coletivo"
    idColetivo = Column(Integer, primary_key=True, autoincrement=True)
    nome = Column(String(255), unique=True, nullable=False)
    sigla = Column(String(45))
    contato = Column(String(45))
    tipo = Column(String(255))

class CategoriaEvento(Base):
    __tablename__ = "CategoriaEvento"
    idCategoria = Column(Integer, primary_key=True, autoincrement=True)
    nome = Column(String(100))
    descrição = Column(String(255))

class Evento(Base):
    __tablename__ = "Evento"
    codEvento = Column(Integer, primary_key=True, autoincrement=True)
    nome = Column(String(255))
    data_inicio = Column(Date)
    data_fim = Column(Date)
    descrição = Column(String(255))
    carga_horaria = Column(Integer)
    Local_idLocal = Column(Integer, nullable=False)
    Coletivo_nome = Column(String(255), nullable=False)
    CategoriaEvento_idCategoria = Column(Integer, nullable=False)

class Presenca(Base):
    __tablename__ = "Presença"
    idPresenca = Column(Integer, primary_key=True, autoincrement=True)
    Inscrição_numero = Column(Integer, nullable=False)
    horario_checkin = Column(DateTime)
    Presente = Column(String(3))

class Organizador(Base):
    __tablename__ = "Organizador"
    idOrganizador = Column(Integer, primary_key=True, autoincrement=True)
    cargo = Column(String(100))
    Pessoa_cpf = Column(String(11), nullable=False)
    Evento_codEveno = Column(Integer, nullable=False)

class Certificado(Base):
    __tablename__ = "Certificado"
    idCertificado = Column(Integer, primary_key=True, autoincrement=True)
    data_emissao = Column(Date)
    carga_horaria = Column(Integer)
    Inscrição_numero = Column(Integer, nullable=False)
    arquivo_pdf = Column(LargeBinary)