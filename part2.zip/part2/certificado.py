import os
from database import SessionLocal
from models import Certificado
from datetime import date
from sqlalchemy import text


foto = "certificado.png" 

def emitir_novo_certificado(usuario_logado):
    """
    @brief Pega a imagem da pasta, transforma em binario e SALVA no banco de dados (BLOB).
    """
    session = SessionLocal()
    os.system('cls' if os.name == 'nt' else 'clear')
    print("--- EMISSAO DE CERTIFICADO ---")
    
    # Garante que a VIEW de controle existe no banco
    sql_view = """
    CREATE OR REPLACE VIEW vw_certificados_disponiveis AS
    SELECT 
        i.numero AS num_inscricao,
        e.nome AS evento_nome,
        e.carga_horaria,
        i.Pessoa_cpf
    FROM `Inscrição` i
    JOIN Evento e ON i.Evento_codEvento = e.codEvento
    JOIN Presença pr ON i.numero = pr.Inscrição_numero
    WHERE pr.Presente = 'SIM' 
    AND i.numero NOT IN (SELECT Inscrição_numero FROM Certificado);
    """
    
    try:
        session.execute(text(sql_view))
        session.commit()

        # Busca eventos onde o usuario tem presenca confirmada mas nao tem certificado gerado
        query = text("SELECT num_inscricao, evento_nome, carga_horaria FROM vw_certificados_disponiveis WHERE Pessoa_cpf = :cpf")
        disponiveis = session.execute(query, {"cpf": usuario_logado.cpf}).fetchall()

        if not disponiveis:
            print("Nao ha novos certificados disponiveis para emissao.")
            print("Certifique-se de que o organizador confirmou sua presenca.")
        else:
            print("Certificados disponiveis para gerar:")
            for d in disponiveis:
                print(f"ID INSCRICAO: {d[0]} | EVENTO: {d[1]}")

            escolha = input("\nDigite o ID da Inscricao para emitir o certificado: ")
            evento_alvo = next((x for x in disponiveis if str(x[0]) == escolha), None)

            if evento_alvo:
                # --- PROCESSO BLOB: INSERINDO A IMAGEM NO BANCO ---
                if os.path.exists(foto):
                    # Abre a imagem que voce criou em modo de leitura binaria ('rb')
                    with open(foto, "rb") as arquivo:
                        blob_da_imagem = arquivo.read() # Aqui a imagem vira binario
                    
                    novo_cert = Certificado(
                        data_emissao=date.today(),
                        carga_horaria=evento_alvo[2],
                        Inscrição_numero=evento_alvo[0],
                        arquivo_pdf=blob_da_imagem # O binario e salvo na coluna BLOB
                    )
                    session.add(novo_cert)
                    session.commit()
                    print("\nSUCESSO: O certificado foi gravado no Banco de Dados!")
                else:
                    print(f"\nERRO: O arquivo '{foto}' nao foi encontrado na pasta.")
            else:
                print("ID invalido.")
                
    except Exception as e:
        session.rollback()
        print(f"Erro ao processar: {e}")
    finally:
        session.close()
        input("\nPressione Enter para continuar...")

def ver_meus_certificados(usuario_logado):
    """
    @brief Busca o binario (BLOB) no banco e transforma de volta em arquivo de imagem no computador.
    """
    session = SessionLocal()
    os.system('cls' if os.name == 'nt' else 'clear')
    print("--- MEUS CERTIFICADOS EMITIDOS ---")
    
    try:
        query = text("""
            SELECT c.idCertificado, e.nome, c.data_emissao 
            FROM Certificado c
            JOIN `Inscrição` i ON c.Inscrição_numero = i.numero
            JOIN Evento e ON i.Evento_codEvento = e.codEvento
            WHERE i.Pessoa_cpf = :cpf
        """)
        meus = session.execute(query, {"cpf": usuario_logado.cpf}).fetchall()

        if not meus:
            print("Voce ainda nao possui certificados emitidos.")
        else:
            for c in meus:
                print(f"ID CERTIFICADO: {c[0]} | EVENTO: {c[1]} | DATA: {c[2]}")

            op = input("\nDigite o ID do certificado para baixar (ou 0 para voltar): ")
            
            if op != '0':
                cert_db = session.query(Certificado).filter_by(idCertificado=op).first()
                
                if cert_db:
                    # --- PROCESSO BLOB: TRANSFORMANDO BINARIO EM ARQUIVO NOVAMENTE ---
                    nome_saida = f"Certificado_Baixado_ID_{op}.png"
                    
                    # Abre um novo arquivo em modo de escrita binaria ('wb')
                    with open(nome_saida, "wb") as f:
                        f.write(cert_db.arquivo_pdf) # Escreve os bits do banco no arquivo
                    
                    print(f"\nDOWNLOAD CONCLUIDO: Arquivo '{nome_saida}' criado com sucesso!")
                else:
                    print("Certificado nao encontrado.")
                    
    except Exception as e:
        print(f"Erro ao baixar: {e}")
    finally:
        session.close()
        input("\nPressione Enter para voltar...")