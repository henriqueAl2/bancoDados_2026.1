from inicio import SistemaEventosBase
from models import Pessoa
from database import SessionLocal

class SistemaComAutenticacao(SistemaEventosBase):
    def __init__(self):
        self.usuario_logado = None
# No login.py, altere a assinatura do método:
    def fazer_login(self, ir_para_inscricao=False):
        print("\n--- LOGIN ---")
        email = input("Email: ")
        senha = input("Senha: ")

        session = SessionLocal()
        usuario = session.query(Pessoa).filter_by(email=email).first()

        if not usuario:
            print("❌ Email não cadastrado!")
            return 

        if usuario.senha != senha:
            print("❌ Senha incorreta!")
            return

        # Se login ok:
        if ir_para_inscricao:
            # Se veio de 'ver eventos', vai direto para inscrição
            self.redirecionar_inscricao(usuario)
        else:
            # Login normal vai para a área de usuário
            self.area_usuario(usuario)
            
    def area_usuario(self, pessoa):
        """Metodo virtual que será implementado no sistemas.py"""
        pass