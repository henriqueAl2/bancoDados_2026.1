import os
from areaUsuario import AreaUsuarioController
from database import SessionLocal
import conta  
import organizador 
import verEventos 
import inscricao

class SistemaFinal(AreaUsuarioController):
    """
    Classe final que implementa os métodos abstratos.
    """
    def ver_eventos(self):
        opcao = verEventos.exibir_lista_eventos()
        if opcao == '1':
            # Passa True para o login saber que deve ir para a inscrição depois
            self.fazer_login(ir_para_inscricao=True)

    def redirecionar_inscricao(self, usuario):
        """Método que faz a ponte entre login e inscrição"""
        inscricao.realizar_inscricao_automatica(usuario)
        # Após se inscrever, ele cai na área de usuário normal
        self.area_usuario(usuario)

    def criar_conta(self):
        conta.executar_cadastro() 
        input("\nEnter para voltar...")

    def ver_eventos(self):
        opcao = verEventos.exibir_lista_eventos()
        if opcao == '1':
            self.fazer_login()

    # CORREÇÃO AQUI: O nome deve ser EXATAMENTE igual ao do areaUsuario.py
    def cadastrar_como_organizador(self):
        # Passa o usuário logado para o módulo de organizador
        organizador.cadastrar_evento_completo(self.usuario_logado)