import os
from areaUsuario import AreaUsuarioController
from login import SistemaComAutenticacao
from database import SessionLocal
from models import Pessoa
from sqlalchemy import text
import conta, organizador, verEventos, inscricao 

class SistemaFinal(AreaUsuarioController, SistemaComAutenticacao):
    """
    @brief Classe de implementação final do sistema.
    """

    def criar_conta(self):
        conta.executar_cadastro()

    def ver_eventos(self):
        """Visualização de eventos inicial com redirecionamento de login."""
        opcao = verEventos.exibir_lista_eventos()
        if opcao == '1':
            self.fazer_login(ir_para_inscricao=True)

    def redirecionar_inscricao(self, usuario):
        """Fluxo após login vindo da tela de eventos."""
        inscricao.realizar_inscricao_automatica(usuario)
        self.area_usuario(usuario)

    def cadastrar_como_organizador(self):
        """Abre o menu de gestão do organizador."""
        organizador.menu_organizador(self.usuario_logado)

    def excluir_usuario(self):
        """
        @brief Remove o usuário, seus eventos organizados e todas as inscrições.
        """
        print("\n" + "!"*40)
        print("⚠️  AVISO: EXCLUSÃO TOTAL DE CONTA")
        print("Isso apagará VOCÊ e TODOS os EVENTOS que você criou.")
        print("!"*40)
        
        if input("Confirme sua SENHA para DELETAR TUDO: ") == self.usuario_logado.senha:
            session = SessionLocal()
            try:
                cpf_alvo = self.usuario_logado.cpf
                
                # 1. BUSCAR TODOS OS EVENTOS QUE ESTA PESSOA ORGANIZA
                query_ev = text("SELECT Evento_codEveno FROM Organizador WHERE Pessoa_cpf = :cpf")
                eventos_organizados = session.execute(query_ev, {"cpf": cpf_alvo}).fetchall()
                
                # 2. PARA CADA EVENTO ENCONTRADO, LIMPAR DEPENDÊNCIAS E APAGAR O EVENTO
                for ev in eventos_organizados:
                    cod_ev = ev[0]
                    # Apaga inscrições de todas as pessoas nesse evento
                    session.execute(text("DELETE FROM `Inscrição` WHERE Evento_codEvento = :cod"), {"cod": cod_ev})
                    # Apaga outros possíveis organizadores desse evento
                    session.execute(text("DELETE FROM Organizador WHERE Evento_codEveno = :cod"), {"cod": cod_ev})
                    # Apaga o evento em si
                    session.execute(text("DELETE FROM Evento WHERE codEvento = :cod"), {"cod": cod_ev})

                # 3. LIMPAR INSCRIÇÕES QUE O USUÁRIO FEZ EM EVENTOS DE OUTRAS PESSOAS
                session.execute(text("DELETE FROM `Inscrição` WHERE Pessoa_cpf = :cpf"), {"cpf": cpf_alvo})
                
                # 4. LIMPAR VÍNCULOS RESTANTES EM ORGANIZADOR
                session.execute(text("DELETE FROM Organizador WHERE Pessoa_cpf = :cpf"), {"cpf": cpf_alvo})
                
                # 5. APAGAR A PESSOA (REGISTRO PAI)
                pessoa_db = session.query(Pessoa).filter_by(cpf=cpf_alvo).first()
                session.delete(pessoa_db)
                
                session.commit()
                print("\n✅ Conta e eventos associados removidos com sucesso.")
                input("Pressione Enter...")
                return True 

            except Exception as e:
                session.rollback()
                print(f"\n❌ Erro ao processar exclusão total: {e}")
                input("Pressione Enter...")
                return False
            finally:
                session.close()
        else:
            print("\n❌ Senha incorreta. Operação cancelada.")
            input("Pressione Enter...")
            return False