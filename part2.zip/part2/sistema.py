import os
from areaUsuario import AreaUsuarioController
from login import SistemaComAutenticacao
from database import SessionLocal
from models import Pessoa
from sqlalchemy import text
import conta, organizador, verEventos, inscricao 

class SistemaFinal(AreaUsuarioController, SistemaComAutenticacao):
    """
    @brief Classe de implementação final do sistema.
    """

    def criar_conta(self):
        conta.executar_cadastro()

    def ver_eventos(self):
        """Visualização de eventos inicial com redirecionamento de login."""
        opcao = verEventos.exibir_lista_eventos()
        if opcao == '1':
            self.fazer_login(ir_para_inscricao=True)

    def redirecionar_inscricao(self, usuario):
        """Fluxo após login vindo da tela de eventos."""
        inscricao.realizar_inscricao_automatica(usuario)
        self.area_usuario(usuario)

    def cadastrar_como_organizador(self):
        """Abre o menu de gestão do organizador."""
        organizador.menu_organizador(self.usuario_logado)

    def excluir_usuario(self):
        print("\n--- SOLICITAÇÃO DE EXCLUSÃO DE CONTA ---")
        if input("Confirme sua SENHA: ") == self.usuario_logado.senha:
            session = SessionLocal()
            try:
                session.execute(text("CALL mydb.sp_deletar_usuario_seguro(:cpf)"), {"cpf": self.usuario_logado.cpf})
                session.commit()
                print("\nConta excluída com sucesso!")
                input("Pressione Enter para voltar ao menu inicial...")
                return True
                
            except Exception as e:
                session.rollback()
                erro_completo = str(e)
                
                if "45000" in erro_completo:
                    print("\n" + "!"*45)
                    print("OPERAÇÃO NEGADA PELO BANCO DE DADOS:")
                    # Extrai apenas a mensagem definida no SIGNAL do SQL
                    if "ORGANIZADOR" in erro_completo:
                        print("Você é ORGANIZADOR de eventos ativos.")
                        print("Exclua seus eventos antes de deletar sua conta.")
                    else:
                        print("Erro de integridade nos dados.")
                    print("!"*45)
                else:
                    print(f"\nErro técnico: {erro_completo}")
                
                input("\nPressione Enter para continuar...")
                return False
            finally:
                session.close()
        return False