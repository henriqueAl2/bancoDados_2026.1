import inicio
import dominios
import builtins

respostas_simuladas = []
mensagens_na_tela = []

def meu_input_falso(prompt):
    # Se a lista tiver itens, retira o primeiro. Se estiver vazia, retorna vazio.
    if len(respostas_simuladas) > 0:
        resp = respostas_simuladas.pop(0)
        return resp
    return ""

def meu_print_falso(*args):
    # Salva o que o programa imprimiu para conferirmos depois
    texto = " ".join(map(str, args))
    mensagens_na_tela.append(texto)

# Trocando as funções originais pelas de teste
builtins.input = meu_input_falso
builtins.print = meu_print_falso
inicio.os.system = lambda x: None # Impede que a tela limpe nos testes

def verificar(texto):
    # Verifica se o texto esperado apareceu em algum print do programa
    return any(texto in msg for msg in mensagens_na_tela)

# --- EXECUÇÃO DOS TESTES ---

def testar_tudo():
    global respostas_simuladas, mensagens_na_tela
    print("Testando: Cadastrar Curso...")
    respostas_simuladas = ["Computacao", "BCC", "CACIC", "BaterADS", "CIC", ""]
    mensagens_na_tela = []
    
    inicio.cadastrar_curso()
    
    if verificar("Dados do curso validados com sucesso!"):
        print("OK: Curso validado com sucesso.")
    else:
        print("FALHA: Erro ao validar curso.")


    print("\nTestando: Cadastrar Pessoa (CPF Errado)...")
    # Respostas: Nome, CPF Curto, Enter do pausar()
    respostas_simuladas = ["Joao Silva", "123", ""]
    mensagens_na_tela = []
    
    inicio.cadastrar_pessoa()
    
    if verificar("Erro: CPF deve ter 11 dígitos numéricos!"):
        print("OK: Barrou CPF inválido.")
    else:
        print("FALHA: Não barrou CPF curto.")

    print("\nTestando: Cadastrar Pessoa (Sucesso)...")
    # Forçamos o dominios a aceitar qualquer curso apenas para este teste
    dominios.validar_curso_no_banco = lambda x: True 
    
    respostas_simuladas = ["Ana Maria", "12345678901", "ana@unb.br", "11988887777", "10/10/2000", "Computacao", ""]
    mensagens_na_tela = []
    
    inicio.cadastrar_pessoa()
    
    if verificar("Todos os dados são válidos!"):
        print("OK: Pessoa validada com sucesso.")
    else:
        print("FALHA: Erro ao validar pessoa correta.")

    print("\nTestando: Cadastrar Evento...")
    # Respostas: Nome, Início, Fim, Desc, Carga, Local, Coletivo, Categoria, Enter do pausar()
    respostas_simuladas = ["Festa", "20/12/2024", "21/12/2024", "Evento de teste", "10", "Predio 1", "UnB", "Social", ""]
    mensagens_na_tela = []
    
    inicio.cadastrar_evento()
    
    if verificar("Evento validado com sucesso!"):
        print("OK: Evento validado com sucesso.")
    else:
        print("FALHA: Erro ao validar evento.")
        
    print("\nTestando: Login (Email Errado)...")
    # Respostas: Email sem @, Enter do pausar()
    respostas_simuladas = ["email_sem_arroba", ""]
    mensagens_na_tela = []
    
    inicio.fazer_login()
    
    if verificar("Erro: E-mail com formato inválido!"):
        print("OK: Barrou login com email sem @.")
    else:
        print(" FALHA: Aceitou email inválido no login.")

if __name__ == "__main__":
    print("=== INICIANDO TESTES UNITÁRIOS DO INÍCIO ===\n")
    testar_tudo()
    print("\n=== FIM DOS TESTES ===")