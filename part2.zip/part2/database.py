from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

USUARIO = "root"
SENHA = "root"
HOST = "127.0.0.1"
PORTA = "3306"
BANCO_DE_DADOS = "mydb"

URL_CONEXAO = f"mysql+mysqlconnector://root:root@127.0.0.1:3306/mydb"

engine = create_engine(URL_CONEXAO)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
