from database import SessionLocal
from models import Curso

def validar_nome(nome):
    if len(nome) > 25:
        return False
    if len(nome) == 0:
        return False
    return True

def validar_cpf(cpf):
    # Verifica se tem 11 caracteres e se todos são números
    if len(cpf) != 11:
        return False
    if cpf.isdigit() == False:
        return False
    return True

def validar_email(email):
    if len(email) > 100:
        return False
    
    # Verifica se tem exatamente um @
    if email.count('@') != 1:
        return False
    
    usuario, dominio = email.split('@')
    
    # Verifica se o domínio tem pelo menos um ponto
    if '.' not in dominio:
        return False
        
    return True

def validar_telefone(telefone):
    # Verifica se é número e o tamanho do DDD + número
    if telefone.isdigit() and (len(telefone) == 10 or len(telefone) == 11):
        return True
    return False

def validar_data(data):
    # Formato esperado: 10/10/2024 (10 caracteres)
    if len(data) != 10:
        return False
    if data[2] != '/' or data[5] != '/':
        return False
    
    # Tenta ver se o que sobrou são números
    partes = data.split('/') # vai gerar ['10', '10', '2024']
    if len(partes) != 3:
        return False
        
    for p in partes:
        if not p.isdigit():
            return False
    return True

def validar_curso_no_banco(nome_curso):
    db = SessionLocal()
    # Usando .with_entities(Curso.nome) forçamos o SQLAlchemy a NÃO buscar o centro_academico
    curso = db.query(Curso).with_entities(Curso.nome).filter(Curso.nome == nome_curso).first()
    db.close()
    return True if curso else False

def validar_texto_longo(texto):
    if len(texto) <= 255:
        return True
    return False

def validar_texto_curto(texto):
    # Para colunas VARCHAR(45) como sigla, atletica e centro_academico
    if len(texto) <= 45:
        return True
    return False

# --- NOVA REGRA DE VALIDAÇÃO DE SENHA ---
def validar_senha(senha):
    # Regra 1: Tamanho mínimo de 8 caracteres
    if len(senha) != 6:
        return False
    
    tem_numero = False
    tem_maiuscula = False
    
    # Regra 2 e 3: Percorre a senha verificando cada letra
    for caractere in senha:
        if caractere.isdigit():
            tem_numero = True
        if caractere.isupper():
            tem_maiuscula = True
            
    # Retorna True apenas se tiver número E maiúscula
    if tem_numero == True and tem_maiuscula == True:
        return True
    else:
        return False