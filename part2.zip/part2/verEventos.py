import os
from database import SessionLocal
from sqlalchemy import text

def exibir_lista_eventos():
    os.system('cls' if os.name == 'nt' else 'clear')
    session = SessionLocal()
    
    # --- VIEW ATUALIZADA COM COUNT E GROUP BY ---
    # Adicionamos COUNT(i.numero) para contar as inscrições vinculadas ao evento
    sql_criacao_view = """
    CREATE OR REPLACE VIEW view_eventos_ativos AS
    SELECT 
        e.codEvento AS id,
        e.nome AS nome_evento,
        p.nome AS organizador,
        o.cargo AS cargo,
        e.Coletivo_nome AS coletivo,
        CONCAT(l.predio, ' - ', l.sala) AS local,
        e.data_inicio AS data,
        COUNT(i.numero) AS total_inscritos
    FROM Evento e
    LEFT JOIN Organizador o ON e.codEvento = o.Evento_codEveno
    LEFT JOIN Pessoa p ON o.Pessoa_cpf = p.cpf
    LEFT JOIN Local l ON e.Local_idLocal = l.idLocal
    LEFT JOIN `Inscrição` i ON e.codEvento = i.Evento_codEvento
    GROUP BY e.codEvento, p.nome, o.cargo, l.predio, l.sala;
    """
    
    try:
        # Garante que a VIEW está atualizada no banco
        session.execute(text(sql_criacao_view))
        session.commit()

        # Cabeçalho com a nova coluna 'PARTIC.' (Participantes)
        header = f"{'ID':<4} | {'EVENTO':<25} | {'ORGANIZADOR (CARGO)':<25} | {'COLETIVO':<15} | {'PARTIC.':<8} | {'DATA':<12}"
        print("=" * len(header))
        print(header)
        print("=" * len(header))

        result = session.execute(text("SELECT * FROM view_eventos_ativos"))
        eventos = result.fetchall()

        if not eventos:
            print(f"{'Nenhum evento ativo no momento.':^100}")
        else:
            for ev in eventos:
                # Mapeamento dos índices conforme a nova VIEW:
                # ev[0]=id, ev[1]=nome, ev[2]=org, ev[3]=cargo, ev[4]=col, ev[5]=local, ev[6]=data, ev[7]=total
                
                nome_ev = (ev[1][:22] + '..') if len(ev[1]) > 24 else ev[1]
                
                org_info = f"{ev[2]} ({ev[3]})" if ev[2] else "N/A"
                org_info = (org_info[:22] + '..') if len(org_info) > 24 else org_info
                
                coletivo = (ev[4][:13] + '..') if len(ev[4]) > 14 else ev[4]

                # Impressão da linha com a contagem de inscritos (ev[7])
                print(f"{ev[0]:<4} | {nome_ev:<25} | {org_info:<25} | {coletivo:<15} | {ev[7]:^8} | {ev[6]}")
                
                print(f"{'':<7} LOCAL: {ev[5]}")
                print("-" * len(header))

    except Exception as e:
        print(f"Erro ao acessar banco de dados: {e}")
    finally:
        session.close()

    print("\n" + "=" * 30)
    print("[1] INSCREVER-SE (Ir para Login)")
    print("[0] Voltar")
    print("=" * 30)
    
    return input("\nEscolha uma opção: ")