import os
from abc import ABC, abstractmethod

# --- INTERFACE ABSTRATA (CONTRATO BASE) ---
class SistemaEventosBase(ABC):
    """
    Define as acoes principais que o sistema deve ter.
    A implementacao real (banco de dados e logica) sera feita nos arquivos filhos.
    """

    @abstractmethod
    def criar_conta(self):
        """Implementacao obrigatoria para cadastro de novos usuarios"""
        pass

    @abstractmethod
    def ver_eventos(self):
        """Implementacao obrigatoria para listagem de eventos (VIEW)"""
        pass

    @abstractmethod
    def fazer_login(self):
        """
        Sera implementado no login.py. 
        Este metodo deve solicitar CPF/Senha e validar o acesso.
        """
        pass


# --- CONTROLADOR DA INTERFACE DE USUARIO (CLI) ---
class MenuPrincipal:
    def __init__(self, sistema: SistemaEventosBase):
        """
        O Menu nao sabe COMO as coisas funcionam, ele apenas sabe que 
        o objeto 'sistema' segue o contrato definido acima.
        """
        self.sistema = sistema

    def limpar_tela(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def exibir_menu(self):
        while True:
            self.limpar_tela()
            print("="*30)
            print("SISTEMA DE GESTÃO DE EVENTOS")
            print("="*30)
            print("1. Criar Conta")
            print("2. Ver Eventos")
            print("3. Fazer Login")
            print("0. Sair")
            print("="*30)
            
            opcao = input("Escolha uma opção: ")

            if opcao == '1':
                self.sistema.criar_conta()
            elif opcao == '2':
                self.sistema.ver_eventos()
            elif opcao == '3':
                # Aqui sera chamada a implementacao que esta no login.py
                self.sistema.fazer_login()
            elif opcao == '0':
                print("Saindo do sistema...")
                break
            else:
                input("Opção inválida! Pressione Enter para tentar novamente.")

if __name__ == "__main__":
    print("Este arquivo e a base do sistema e nao deve ser executado sozinho.")