import os
import dominios
from datetime import datetime
from sqlalchemy import text
from database import SessionLocal
from models import Curso, Pessoa, Evento, Local, Coletivo, CategoriaEvento, Organizador

def limpar_tela():
    os.system('cls' if os.name == 'nt' else 'clear')

def pausar():
    input("\nPressione Enter para continuar...")
#Inicio da tela
def menu_principal():
    while True:
        limpar_tela()
        print("="*30)
        print("SISTEMA DE GESTÃO DE EVENTOS")
        print("="*30)
        print("1. Cadastrar Pessoa")
        print("2. Cadastrar Evento")
        print("3. Cadastrar Curso")
        print("4. Ver Eventos")
        print("5. Login")
        print("0. Sair")
        print("="*30)
        
        opcao = input("Escolha uma opcao: ")

        if opcao == '1': cadastrar_pessoa()
        elif opcao == '2': cadastrar_evento()
        elif opcao == '3': cadastrar_curso()
        elif opcao == '4': ver_eventos()
        elif opcao == '5': fazer_login()
        elif opcao == '0': break

#Aqui o programa le ou cria com base na inexistencia algum objeto para o banco
def buscar_ou_criar_local(db, predio, sala):
    local = db.query(Local).filter(Local.predio == predio, Local.sala == sala).first()
    if not local:
        print(f"Local {predio}-{sala} nao encontrado. Cadastrando agora...")
        acessivel = input("O local e acessivel? (1-Sim/0-Nao): ")
        local = Local(predio=predio, sala=sala, acessivel=int(acessivel), Feedback_idFeedback=0)
        db.add(local)
        db.flush() 
    return local

def buscar_ou_criar_coletivo(db, nome_col):
    coletivo = db.query(Coletivo).filter(Coletivo.nome == nome_col).first()
    if not coletivo:
        print(f"Coletivo '{nome_col}' nao encontrado. Cadastrando agora...")
        sigla = input("Sigla do coletivo organizador:" )
        contato = input("Contato: ")
        tipo = input("Tipo: ")
        coletivo = Coletivo(nome=nome_col, sigla=sigla, contato=contato, tipo=tipo)
        db.add(coletivo)
        db.flush()
    return coletivo

def buscar_ou_criar_categoria(db, nome_cat):
    categoria = db.query(CategoriaEvento).filter(CategoriaEvento.nome == nome_cat).first()
    if not categoria:
        print(f"Categoria '{nome_cat}' nao encontrada. Cadastrando agora...")
        desc = input("Descricao da categoria: ")
        categoria = CategoriaEvento(nome=nome_cat, descrição=desc)
        db.add(categoria)
        db.flush()
    return categoria


#Funcionalidades da tela
def cadastrar_evento():
    limpar_tela()
    print("--- CADASTRO DE EVENTO ---")
    
    nome_ev = input("Nome do Evento: ")
    d_ini = input("Data Inicio (DD/MM/AAAA): ")
    d_fim = input("Data Fim (DD/MM/AAAA): ")
    desc = input("Descricao: ")
    carga = input("Carga Horaria: ")

    db = SessionLocal()
    try:
        # 1. Local (Cria se nao existir)
        p = input("Predio: ")
        s = input("Sala: ")
        obj_local = buscar_ou_criar_local(db, p, s)

        # 2. Coletivo (Cria se nao existir)
        n_col = input("Nome do Coletivo Responsavel: ")
        obj_coletivo = buscar_ou_criar_coletivo(db, n_col)

        # 3. Categoria (Cria se nao existir)
        n_cat = input("Nome da Categoria: ")
        obj_cat = buscar_ou_criar_categoria(db, n_cat)

        # 4. Criar o Evento
        novo_evento = Evento(
            nome=nome_ev,
            data_inicio=datetime.strptime(d_ini, "%d/%m/%Y").date(),
            data_fim=datetime.strptime(d_fim, "%d/%m/%Y").date(),
            descrição=desc,
            carga_horaria=int(carga),
            Local_idLocal=obj_local.idLocal,
            Coletivo_nome=obj_coletivo.nome,
            CategoriaEvento_idCategoria=obj_cat.idCategoria
        )
        db.add(novo_evento)
        db.flush() 

        # 5. Atribuir Organizador (REGRA: Pessoa JA deve ter conta)
        print("\n--- ATRIBUIR ORGANIZADOR ---")
        cpf_org = input("CPF do Organizador (Deve estar cadastrado): ")
        pessoa = db.query(Pessoa).filter(Pessoa.cpf == cpf_org).first()
        
        if not pessoa:
            print("Erro: Esta pessoa nao possui conta. Cadastre-a primeiro na opcao 1.")
            db.rollback()
            return pausar()
        
        cargo = input("Cargo do organizador: ")
        novo_org = Organizador(
            cargo=cargo,
            Pessoa_cpf=pessoa.cpf,
            Evento_codEveno=novo_evento.codEvento
        )
        db.add(novo_org)
        
        db.commit()
        print(f"\nSucesso: Evento '{nome_ev}' e Organizador '{pessoa.nome}' cadastrados!")

    except Exception as e:
        print(f"\nErro no processo: {e}")
        db.rollback()
    finally:
        db.close()
    pausar()

def ver_eventos():
    limpar_tela()
    print("--- EVENTOS EXISTENTES ---")
    db = SessionLocal()
    try:
        query = text("SELECT * FROM vw_agenda_completa")
        resultados = db.execute(query).fetchall()
        if not resultados:
            print("Nenhum evento encontrado.")
        else:
            print(f"{'Evento':<20} | {'Data':<12} | {'Local':<20} | {'Categoria':<15}")
            print("-" * 75)
            for linha in resultados:
                data_ev = linha[1].strftime("%d/%m/%Y") if linha[1] else "N/A"
                print(f"{linha[0]:<20} | {data_ev:<12} | {linha[3]}({linha[2]}):<20 | {linha[4]:<15}")
    except Exception as e:
        print(f"Erro ao ler eventos: {e}")
    finally:
        db.close()
    pausar()

def cadastrar_curso():
    limpar_tela()
    print("--- CADASTRO DE CURSO ---")
    nome = input("Nome do Curso: ")
    if not dominios.validar_texto_longo(nome):
        print("Erro: Nome invalido!"); return pausar()
    sigla = input("Sigla: ")
    ca = input("Centro Academico: ")
    atl = input("Atletica: ")
    dep = input("Departamento: ")
    db = SessionLocal()
    try:
        novo = Curso(nome=nome, sigla=sigla, centro_academico=ca, atletica=atl, departamento_responsalvel=dep)
        db.add(novo)
        db.commit()
        print("Sucesso: Curso cadastrado!")
    except Exception as e:
        print(f"Erro: {e}"); db.rollback()
    finally: db.close()
    pausar()

def cadastrar_pessoa():
    limpar_tela()
    print("--- CADASTRO DE PESSOA ---")
    nome = input("Nome: ")
    if not dominios.validar_nome(nome):
        print("Erro: Nome invalido!"); return pausar()
    cpf = input("CPF: ")
    if not dominios.validar_cpf(cpf):
        print("Erro: CPF invalido!"); return pausar()
    email = input("Email: ")
    fone = input("Telefone: ")
    data = input("Data Nasc (DD/MM/AAAA): ")
    curso_n = input("Nome do Curso: ")
    db = SessionLocal()
    try:
        cur = db.query(Curso).filter(Curso.nome == curso_n).first()
        if not cur:
            print("Erro: Curso nao existe!"); return pausar()
        nova = Pessoa(cpf=cpf, nome=nome, email=email, telefone=fone, 
                      data_nasc=datetime.strptime(data, "%d/%m/%Y").date(), 
                      Curso_idCurso=cur.idCurso)
        db.add(nova)
        db.commit()
        print("Sucesso: Pessoa cadastrada!")
    except Exception as e:
        print(f"Erro: {e}"); db.rollback()
    finally: db.close()
    pausar()

def fazer_login():
    limpar_tela()
    print("--- LOGIN ---")
    email = input("Email: ")
    senha = input("CPF: ")
    db = SessionLocal()
    user = db.query(Pessoa).filter(Pessoa.email == email, Pessoa.cpf == senha).first()
    db.close()
    if user: print(f"Bem-vindo(a), {user.nome}!")
    else: print("Dados incorretos.")
    pausar()