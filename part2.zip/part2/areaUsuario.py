import os
from abc import abstractmethod
from sqlalchemy import text
from database import SessionLocal
from models import Pessoa
import verEventos
import inscricao 

class AreaUsuarioController:
    """
    @brief Classe controladora da interface do usuário logado.
    @details Gerencia o menu principal pós-login e as ações de visualização e atualização.
    """

    @abstractmethod
    def cadastrar_como_organizador(self):
        """Implementado no sistema.py para chamar o menu do organizador."""
        pass

    @abstractmethod
    def excluir_usuario(self):
        """Implementado no sistema.py para realizar a exclusão no banco."""
        pass

    def area_usuario(self, pessoa):
        """
        @brief Loop principal da área logada.
        @param pessoa Objeto da classe Pessoa carregado do banco.
        """
        self.usuario_logado = pessoa
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("="*50)
            print(f"--- ÁREA DO USUÁRIO ---")
            print(f"BEM-VINDO(A), {self.usuario_logado.nome.upper()}")
            print(f"CPF: {self.usuario_logado.cpf}")
            
            # Exibe o curso usando o relationship definido no models.py
            curso_nome = self.usuario_logado.curso.nome if self.usuario_logado.curso else "Não informado"
            print(f"CURSO: {curso_nome}")
            print("="*50)
            
            print("1. Ver Meus Eventos Inscritos (VIEW)")
            print("2. Atualizar Meus Dados")
            print("3. Gestão de Organizador (Criar/Excluir Eventos)")
            print("4. Inscrever-se em um Novo Evento")
            print("5. ❌ EXCLUIR MINHA CONTA")
            print("0. Sair (Logout)")
            print("-" * 50)
            
            opcao = input("Escolha uma opção: ")

            if opcao == '1':
                self.ver_eventos_inscritos()
            elif opcao == '2':
                self.atualizar_cadastro()
            elif opcao == '3':
                self.cadastrar_como_organizador() 
            elif opcao == '4':
                self.inscrever_se_evento_logado()
            elif opcao == '5':
                # Chama a exclusão e encerra a sessão se retornar True
                if self.excluir_usuario():
                    break
            elif opcao == '0':
                break
            else:
                input("Opção inválida! Enter para continuar...")

    def inscrever_se_evento_logado(self):
        """Fluxo direto: Mostra lista e vai para inscrição sem novo login."""
        verEventos.exibir_lista_eventos()
        inscricao.realizar_inscricao_automatica(self.usuario_logado)

    def ver_eventos_inscritos(self):
        """Lista eventos que o usuário está participando via VIEW."""
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"--- EVENTOS DE {self.usuario_logado.nome.upper()} ---")
        db = SessionLocal()
        try:
            query = text("SELECT evento_nome, data_inicio, predio, sala FROM vw_meus_eventos WHERE Pessoa_cpf = :cpf")
            resultados = db.execute(query, {"cpf": self.usuario_logado.cpf}).fetchall()

            if not resultados:
                print("\nVocê ainda não possui inscrições em eventos.")
            else:
                print(f"{'EVENTO':<25} | {'DATA':<12} | {'LOCAL'}")
                print("-" * 60)
                for r in resultados:
                    print(f"{r[0]:<25} | {r[1]} | {r[2]} - {r[3]}")
        except Exception as e:
            print(f"Erro ao carregar inscrições: {e}")
        finally:
            db.close()
        input("\nPressione Enter para voltar...")

    def atualizar_cadastro(self):
        """Atualiza dados permitidos (Nome, Email, Tel)."""
        print("\n--- ATUALIZAR CADASTRO ---")
        novo_nome = input(f"Novo nome [{self.usuario_logado.nome}]: ") or self.usuario_logado.nome
        novo_email = input(f"Novo email [{self.usuario_logado.email}]: ") or self.usuario_logado.email
        novo_tel = input(f"Novo telefone [{self.usuario_logado.telefone}]: ") or self.usuario_logado.telefone
        
        db = SessionLocal()
        try:
            p_banco = db.query(Pessoa).filter(Pessoa.cpf == self.usuario_logado.cpf).first()
            p_banco.nome = novo_nome
            p_banco.email = novo_email
            p_banco.telefone = novo_tel
            db.commit()
            
            # Sincroniza o objeto em memória para atualizar o menu imediatamente
            self.usuario_logado.nome = novo_nome
            self.usuario_logado.email = novo_email
            self.usuario_logado.telefone = novo_tel
            print("\n✅ Cadastro atualizado com sucesso!")
        except Exception as e:
            db.rollback()
            print(f"❌ Erro ao atualizar: {e}")
        finally:
            db.close()
        input("\nPressione Enter para continuar...")

    @abstractmethod
    def criar_conta(self): pass
    @abstractmethod
    def ver_eventos(self): pass