import os
from abc import abstractmethod
from sqlalchemy import text
from database import SessionLocal
from models import Pessoa, Inscricao, Evento
from datetime import date
import login
import verEventos
import inscricao # Importado para a opção 4

class AreaUsuarioController(login.SistemaComAutenticacao):

    # --- REQUISITOS ABSTRATOS ---
    @abstractmethod
    def cadastrar_como_organizador(self):
        """Implementado no sistema.py"""
        pass

    @abstractmethod
    def criar_conta(self): pass

    @abstractmethod
    def ver_eventos(self): pass

    # --- TELA PRINCIPAL ---
    def area_usuario(self, pessoa):
        self.usuario_logado = pessoa
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("="*40)
            print(f"--- ÁREA DO USUÁRIO ---")
            print(f"BEM-VINDO(A), {self.usuario_logado.nome.upper()}")
            print(f"CPF: {self.usuario_logado.cpf}")
            
            # Tratamento para mostrar o curso com segurança
            curso_nome = self.usuario_logado.curso.nome if self.usuario_logado.curso else "Não informado"
            print(f"CURSO: {curso_nome}")
            print("="*40)
            
            print("1. Ver Eventos Inscritos (VIEW)")
            print("2. Atualizar Cadastro (TRIGGER)")
            print("3. Me Cadastrar como Organizador de Evento")
            print("4. Inscrever-se em Evento Ativo")
            print("0. Sair (Logout)")
            print("-" * 40)
            
            opcao = input("Escolha uma opção: ")

            if opcao == '1':
                self.ver_eventos_inscritos()
            elif opcao == '2':
                self.atualizar_cadastro()
            elif opcao == '3':
                # Corrigido para o nome exato do método abstrato
                self.cadastrar_como_organizador() 
            elif opcao == '4':
                # Chama o método interno da classe
                self.inscrever_se_evento()
            elif opcao == '0':
                break
            else:
                input("Opção inválida! Enter para continuar...")

    # --- REQUISITO: INSCREVER-SE LOGADO ---
    def inscrever_se_evento(self):
        """Permite ao usuário escolher um evento da lista e se inscrever confirmando senha"""
        # Mostra a lista formatada
        verEventos.exibir_lista_eventos()
        # Chama a lógica de inscrição (ID + Senha)
        inscricao.realizar_inscricao_automatica(self.usuario_logado)

    # --- REQUISITO 4: VER EVENTOS INSCRITOS (USO DE VIEW) ---
    def ver_eventos_inscritos(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"--- EVENTOS QUE {self.usuario_logado.nome.upper()} ESTÁ INSCRITO ---")
        
        db = SessionLocal()
        try:
            query = text("SELECT evento_nome, data_inicio, predio, sala FROM mydb.vw_meus_eventos WHERE Pessoa_cpf = :cpf")
            resultados = db.execute(query, {"cpf": self.usuario_logado.cpf}).fetchall()

            if not resultados:
                print("\nVocê ainda não está inscrito em nenhum evento.")
            else:
                print(f"{'EVENTO':<25} | {'DATA':<12} | {'LOCAL'}")
                print("-" * 60)
                for r in resultados:
                    print(f"{r[0]:<25} | {r[1]} | {r[2]} - {r[3]}")
                print("-" * 60)
        except Exception as e:
            print(f"Erro ao acessar View: {e}")
        finally:
            db.close()
        input("\nPressione Enter para voltar...")

    # --- REQUISITO 3: ATUALIZAR CADASTRO ---
    def atualizar_cadastro(self):
        print("\n--- ATUALIZAR CADASTRO ---")
        print("Nota: CPF e Data de Nascimento não podem ser alterados.")
        
        # Sugere o valor atual caso o usuário apenas dê Enter
        novo_nome = input(f"Novo nome [{self.usuario_logado.nome}]: ") or self.usuario_logado.nome
        novo_email = input(f"Novo email [{self.usuario_logado.email}]: ") or self.usuario_logado.email
        novo_tel = input(f"Novo telefone [{self.usuario_logado.telefone}]: ") or self.usuario_logado.telefone
        
        db = SessionLocal()
        try:
            # Busca o objeto para persistência
            p_banco = db.query(Pessoa).filter(Pessoa.cpf == self.usuario_logado.cpf).first()
            p_banco.nome = novo_nome
            p_banco.email = novo_email
            p_banco.telefone = novo_tel
            
            db.commit()
            
            # Atualiza o objeto em memória para refletir no menu imediatamente
            self.usuario_logado.nome = novo_nome
            self.usuario_logado.email = novo_email
            self.usuario_logado.telefone = novo_tel
            
            print("\n✅ Dados atualizados com sucesso!")
        except Exception as e:
            db.rollback()
            print(f"\n❌ Erro ao atualizar: {e}")
        finally:
            db.close()
        input("\nPressione Enter para continuar...")