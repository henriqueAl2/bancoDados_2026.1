import os
from database import SessionLocal
from models import Pessoa, Curso
from datetime import datetime
import curso as modulo_curso # Importa o novo módulo de curso

def executar_cadastro():
    session = SessionLocal()
    os.system('cls' if os.name == 'nt' else 'clear')
    print("="*40)
    print("      CADASTRO DE NOVA CONTA")
    print("="*40)
    
    try:
        # 1. COLETA DE DADOS DA PESSOA
        nome = input("a) Nome Completo: ")
        cpf = input("b) CPF (apenas 11 números): ").strip()
        email = input("d) Email: ")
        senha = input("Senha para login (máx. 6 caracteres): ").strip()
        data_nasc_str = input("e) Data de Nascimento (AAAA-MM-DD): ")
        telefone = input("f) Telefone (Pressione Enter para pular): ")
        curso_nome = input("g) Nome do Curso: ").strip()

        # --- VALIDAÇÕES DE CAMPOS ---
        
        # Validação: Campos obrigatórios
        if not all([nome, cpf, email, senha, data_nasc_str, curso_nome]):
            print("\n❌ Erro: Todos os campos (exceto telefone) são obrigatórios!")
            return

        # Validação: Tamanho do CPF (Evita erro 1406 no MySQL)
        if len(cpf) > 11:
            print(f"\n❌ Erro: O CPF '{cpf}' é muito longo ({len(cpf)} dígitos). O máximo é 11.")
            return

        # Validação: Tamanho da Senha (VARCHAR(6) no seu banco)
        if len(senha) > 6:
            print(f"\n❌ Erro: A senha é muito longa. O máximo permitido são 6 caracteres.")
            return

        # 2. LÓGICA DO CURSO (Integração com curso.py)
        # Tenta buscar o curso no banco pelo nome
        curso_objeto = session.query(Curso).filter_by(nome=curso_nome).first()

        if not curso_objeto:
            # Se o curso não existir, chama o módulo externo curso.py
            # O cadastro da pessoa continua logo após o retorno desta função
            curso_objeto = modulo_curso.cadastrar_novo_curso(session, curso_nome)
            
            # Se o usuário cancelar ou errar o cadastro do curso, interrompemos tudo
            if curso_objeto is None:
                print("\n❌ Cadastro cancelado devido a erro no registro do curso.")
                return

        # 3. REGISTRO DA PESSOA NO BANCO
        # Converter string para objeto Date
        data_nasc = datetime.strptime(data_nasc_str, "%Y-%m-%d").date()

        nova_pessoa = Pessoa(
            cpf=cpf,
            nome=nome,
            email=email,
            telefone=telefone if telefone else None,
            data_nasc=data_nasc,
            senha=senha,
            Curso_idCurso=curso_objeto.idCurso # Usa o ID do curso (existente ou novo)
        )

        session.add(nova_pessoa)
        
        # 4. FINALIZAÇÃO (COMMIT ÚNICO)
        # O commit aqui salva tanto o Curso (se foi criado) quanto a Pessoa de uma vez só
        session.commit()
        print(f"\n✅ SUCESSO: Conta de {nome} criada com sucesso!")

    except ValueError:
        print("\n❌ Erro: Formato de data inválido. Use AAAA-MM-DD.")
    except Exception as e:
        session.rollback()
        print(f"\n❌ Erro ao salvar no banco: {e}")
    finally:
        session.close()
        input("\nPressione Enter para voltar ao Menu Inicial...")