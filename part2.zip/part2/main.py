from inicio import MenuPrincipal
from sistema import SistemaFinal

if __name__ == "__main__":
    # Instancia a implementação final
    sistema = SistemaFinal()
    
    # Passa para o MenuPrincipal que gerencia a tela inicial
    menu = MenuPrincipal(sistema)
    
    # Inicia o loop do programa
    menu.exibir_menu()