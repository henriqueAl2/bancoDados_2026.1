import inicio
import models
from database import engine, Base

def inicializar_banco():
    """
    Verifica a conexao e cria as tabelas no MySQL caso elas nao existam.
    Nota: Views, Procedures e Triggers devem ser criados via script SQL no Workbench.
    """
    print("Verificando conexao com o banco de dados...")
    try:
        # Sincroniza as classes do models.py com as tabelas do MySQL
        Base.metadata.create_all(bind=engine)
        print("Conexao estabelecida e tabelas sincronizadas.")
    except Exception as e:
        print(f"Erro fatal: Nao foi possivel conectar ao banco de dados.")
        print(f"Detalhes: {e}")
        exit()

def executar_sistema():
    """Inicia o fluxo principal do programa."""
    try:
        inicio.menu_principal()
    except KeyboardInterrupt:
        print("\n\nSistema encerrado pelo usuario.")
    except Exception as e:
        print(f"\nOcorreu um erro inesperado no sistema: {e}")

if __name__ == "__main__":
    # 1. Prepara o ambiente de dados
    inicializar_banco()
    
    # 2. Abre a interface de usuario
    executar_sistema()