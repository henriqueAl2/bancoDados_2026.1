import os
from database import SessionLocal
from models import Organizador, Evento, Coletivo, Local, CategoriaEvento, Inscricao, Presenca
from datetime import datetime, date
from sqlalchemy import text

def menu_organizador(usuario_logado):
    """
    @brief Menu de gestão para usuários com perfil de organizador.
    """
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"--- GESTÃO DE EVENTOS: {usuario_logado.nome.upper()} ---")
        print("1. Cadastrar Novo Evento")
        print("2. Excluir um Evento")
        print("3. Confirmar Presença de Participantes")
        print("0. Voltar")
        print("-" * 40)
        
        op = input("Escolha uma opção: ")
        
        if op == '1':
            cadastrar_evento_completo(usuario_logado)
        elif op == '2':
            excluir_evento_organizador(usuario_logado)
        elif op == '3':
            confirmar_presenca_participantes(usuario_logado)
        elif op == '0':
            break

def cadastrar_evento_completo(usuario_logado):
    """
    @brief Realiza o cadastro de Coletivo, Local, Evento e Organizador.
    """
    session = SessionLocal()
    print("\n--- CADASTRO DE NOVO EVENTO ---")
    try:
        print("\n[CATEGORIA DO EVENTO]")
        nome_cat = input("Nome da Categoria (Ex: Palestra, Workshop, Social): ").strip()
        
        categoria = session.query(CategoriaEvento).filter_by(nome=nome_cat).first()
        
        if not categoria:
            print(f"A categoria '{nome_cat}' nao existe. Cadastrando agora.")
            descricao_cat = input("Breve descricao da categoria: ")
            categoria = CategoriaEvento(nome=nome_cat, descrição=descricao_cat)
            session.add(categoria)
            session.flush() # Gera o idCategoria
        # Coletivo
        nome_col = input("Nome do Coletivo/Departamento: ")
        coletivo = session.query(Coletivo).filter_by(nome=nome_col).first()
        if not coletivo:
            coletivo = Coletivo(
                nome=nome_col, 
                sigla=input("Sigla: "), 
                contato=input("Contato: "), 
                tipo="Geral"
            )
            session.add(coletivo)
            session.flush()

        # Local
        novo_local = Local(
            acessivel=1, 
            predio=input("Prédio/Bloco: "), 
            sala=input("Sala/Auditório: "), 
            Feedback_idFeedback=1
        )
        session.add(novo_local)
        session.flush()

        # Evento
        nome_ev = input("Nome do Evento: ")
        data_i = input("Data de Início (AAAA-MM-DD): ")
        novo_evento = Evento(
            nome=nome_ev,
            descrição=input("Descrição do Evento: "),
            data_inicio=datetime.strptime(data_i, "%Y-%m-%d").date(),
            data_fim=datetime.strptime(data_i, "%Y-%m-%d").date(),
            carga_horaria=int(input("Carga Horária total: ")),
            Local_idLocal=novo_local.idLocal,
            Coletivo_nome=coletivo.nome,
            CategoriaEvento_idCategoria=1
        )
        session.add(novo_evento)
        session.flush()

        # Organizador
        cargo = input("Seu cargo na organização deste evento: ")
        novo_org = Organizador(
            cargo=cargo, 
            Pessoa_cpf=usuario_logado.cpf, 
            Evento_codEveno=novo_evento.codEvento
        )
        session.add(novo_org)

        # Inscrição Automática do Organizador
        nova_ins = Inscricao(
            data=date.today(), 
            status="Organizador", 
            Pessoa_cpf=usuario_logado.cpf, 
            Evento_codEvento=novo_evento.codEvento
        )
        session.add(nova_ins)

        session.commit()
        print("\nSUCESSO: Evento cadastrado e organizador registrado.")
    except Exception as e:
        session.rollback()
        print(f"\nERRO: Nao foi possivel cadastrar o evento. {e}")
    finally:
        session.close()
        input("\nPressione Enter para continuar...")

def excluir_evento_organizador(usuario_logado):
    """
    @brief Remove um evento e suas dependencias.
    """
    session = SessionLocal()
    print("\n--- MEUS EVENTOS ---")
    try:
        query = text("SELECT id, nome_evento FROM view_eventos_ativos WHERE organizador = :nome")
        meus_eventos = session.execute(query, {"nome": usuario_logado.nome}).fetchall()
        
        if not meus_eventos:
            print("Nao foram encontrados eventos sob sua responsabilidade.")
            return

        for ev in meus_eventos:
            print(f"ID: {ev[0]} | Nome: {ev[1]}")

        cod = input("\nDigite o ID do evento para exclusao permanente: ")
        
        if input("Confirme sua SENHA para validar a exclusao: ") == usuario_logado.senha:
            session.execute(text(f"DELETE FROM `Inscrição` WHERE Evento_codEvento = {cod}"))
            session.execute(text(f"DELETE FROM Organizador WHERE Evento_codEveno = {cod}"))
            session.execute(text(f"DELETE FROM Evento WHERE codEvento = {cod}"))
            session.commit()
            print("Evento removido com sucesso.")
        else:
            print("Senha incorreta. Operacao cancelada.")
    except Exception as e:
        session.rollback()
        print(f"ERRO ao excluir: {e}")
    finally:
        session.close()
        input("Pressione Enter...")

def confirmar_presenca_participantes(usuario_logado):
    """
    @brief Realiza a chamada de participantes um a um.
    """
    session = SessionLocal()
    os.system('cls' if os.name == 'nt' else 'clear')
    print("--- CHAMADA DE PARTICIPANTES ---")
    
    try:
        query_meus_ev = text("SELECT id, nome_evento FROM view_eventos_ativos WHERE organizador = :nome")
        meus_eventos = session.execute(query_meus_ev, {"nome": usuario_logado.nome}).fetchall()

        if not meus_eventos:
            print("Nao ha eventos cadastrados para realizar chamada.")
            return

        for ev in meus_eventos:
            print(f"ID: {ev[0]} | Evento: {ev[1]}")

        cod_ev = input("\nDigite o ID do evento para iniciar a chamada: ")

        query_inscritos = text("""
            SELECT i.numero, p.nome, p.data_nasc 
            FROM `Inscrição` i
            JOIN Pessoa p ON i.Pessoa_cpf = p.cpf
            WHERE i.Evento_codEvento = :cod
        """)
        inscritos = session.execute(query_inscritos, {"cod": cod_ev}).fetchall()

        if not inscritos:
            print("\nNao ha inscritos para este evento.")
        else:
            print(f"\nParticipantes encontrados: {len(inscritos)}")
            print("-" * 40)
            
            for ins in inscritos:
                print(f"NOME: {ins[1]}")
                print(f"DATA NASCIMENTO: {ins[2]}")
                
                if input(f"Confirmar presenca de {ins[1]}? (S/N): ").upper() == 'S':
                    ja_tem = session.query(Presenca).filter_by(Inscrição_numero=ins[0]).first()
                    if not ja_tem:
                        nova_p = Presenca(
                            Inscrição_numero=ins[0],
                            horario_checkin=datetime.now(),
                            Presente="SIM"
                        )
                        session.add(nova_p)
                        print("Presenca registrada.")
                    else:
                        print("Presenca ja constava no sistema.")
                else:
                    print("Presenca nao registrada.")
                print("-" * 40)

            session.commit()
            print("\nChamada finalizada.")

    except Exception as e:
        session.rollback()
        print(f"ERRO: {e}")
    finally:
        session.close()
        input("\nPressione Enter para retornar ao menu...")