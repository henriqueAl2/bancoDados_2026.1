from database import SessionLocal
from models import Organizador, Evento, Coletivo, Local, CategoriaEvento, Inscricao # Adicionado Inscricao
from datetime import datetime, date # Adicionado date

def cadastrar_evento_completo(usuario_logado):
    """
    Solicita os dados para criar: Coletivo -> Local -> Evento -> Organizador -> Inscrição Automática
    """
    session = SessionLocal()
    print(f"\n--- CADASTRAR COMO ORGANIZADOR ---")
    print(f"Organizador responsável: {usuario_logado.nome}")
    
    try:
        # 1. Dados do Coletivo
        print("\n[DADOS DO COLETIVO]")
        nome_col = input("Nome do Coletivo: ")
        coletivo = session.query(Coletivo).filter_by(nome=nome_col).first()
        
        if not coletivo:
            sigla = input("Sigla do Coletivo: ")
            contato = input("Contato/Link: ")
            tipo = input("Tipo (Ex: Acadêmico, Esportivo): ")
            coletivo = Coletivo(nome=nome_col, sigla=sigla, contato=contato, tipo=tipo)
            session.add(coletivo)
            session.flush()

        # 2. Dados do Local
        print("\n[LOCAL DO EVENTO]")
        predio = input("Prédio/Bloco: ")
        sala = input("Sala/Auditório: ")
        novo_local = Local(acessivel=1, predio=predio, sala=sala, Feedback_idFeedback=1)
        session.add(novo_local)
        session.flush()

        # 3. Dados da Categoria
        cat_nome = input("\nCategoria do Evento (Ex: Palestra): ")
        categoria = session.query(CategoriaEvento).filter_by(nome=cat_nome).first()
        if not categoria:
            categoria = CategoriaEvento(nome=cat_nome, descrição="Cadastrada via sistema")
            session.add(categoria)
            session.flush()

        # 4. Dados do Evento
        print("\n[DADOS DO EVENTO]")
        nome_ev = input("Nome do Evento: ")
        desc = input("Descrição: ")
        data_ini = input("Data Início (AAAA-MM-DD): ")
        data_fim = input("Data Fim (AAAA-MM-DD): ")
        carga = input("Carga Horária: ")

        novo_evento = Evento(
            nome=nome_ev,
            descrição=desc,
            data_inicio=datetime.strptime(data_ini, "%Y-%m-%d").date(),
            data_fim=datetime.strptime(data_fim, "%Y-%m-%d").date(),
            carga_horaria=int(carga),
            Local_idLocal=novo_local.idLocal,
            Coletivo_nome=coletivo.nome,
            CategoriaEvento_idCategoria=categoria.idCategoria
        )
        session.add(novo_evento)
        session.flush()

        # 5. Dados do Organizador (Vínculo de Função)
        print("\n[SEUS DADOS COMO ORGANIZADOR]")
        cargo_org = input("Seu cargo/função neste evento: ")
        
        novo_organizador = Organizador(
            cargo=cargo_org,
            Pessoa_cpf=usuario_logado.cpf,
            Evento_codEveno=novo_evento.codEvento
        )
        session.add(novo_organizador)

        # --- NOVO: 6. INSCRIÇÃO AUTOMÁTICA DO ORGANIZADOR ---
        # Registra o organizador na tabela de Inscrição para que o evento 
        # apareça na lista de "Meus Eventos Inscritos" dele.
        nova_inscricao = Inscricao(
            data=date.today(),
            status="Organizador", # Status especial para identificar
            Pessoa_cpf=usuario_logado.cpf,
            Evento_codEvento=novo_evento.codEvento
        )
        session.add(nova_inscricao)

        session.commit()
        print("\n✅ SUCESSO!")
        print(f"Evento '{nome_ev}' cadastrado.")
        print(f"Você foi registrado como Organizador e sua inscrição foi confirmada automaticamente.")

    except Exception as e:
        session.rollback()
        print(f"❌ Erro ao processar cadastro: {e}")
    finally:
        session.close()
        input("\nPressione Enter para continuar...")