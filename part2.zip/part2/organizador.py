import os
from database import SessionLocal
from models import Organizador, Evento, Coletivo, Local, CategoriaEvento, Inscricao
from datetime import datetime, date
from sqlalchemy import text

def menu_organizador(usuario_logado):
    """
    @brief Menu de sub-página para gestão de eventos.
    """
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"--- GESTÃO DE ORGANIZADOR: {usuario_logado.nome.upper()} ---")
        print("1. Cadastrar Novo Evento")
        print("2. Excluir um Evento (Seu)")
        print("0. Voltar")
        print("-" * 40)
        
        op = input("Escolha uma opção: ")
        if op == '1':
            cadastrar_evento_completo(usuario_logado)
        elif op == '2':
            excluir_evento_organizador(usuario_logado)
        elif op == '0':
            break

def cadastrar_evento_completo(usuario_logado):
    session = SessionLocal()
    print(f"\n--- CADASTRO DE NOVO EVENTO ---")
    try:
        # Coletivo
        nome_col = input("Nome do Coletivo: ")
        col = session.query(Coletivo).filter_by(nome=nome_col).first()
        if not col:
            col = Coletivo(nome=nome_col, sigla=input("Sigla: "), contato=input("Contato: "), tipo="Geral")
            session.add(col); session.flush()

        # Local
        novo_local = Local(acessivel=1, predio=input("Prédio: "), sala=input("Sala: "), Feedback_idFeedback=1)
        session.add(novo_local); session.flush()

        # Evento
        nome_ev = input("Nome do Evento: ")
        data_str = input("Data (AAAA-MM-DD): ")
        novo_evento = Evento(
            nome=nome_ev,
            descrição=input("Descrição: "),
            data_inicio=datetime.strptime(data_str, "%Y-%m-%d").date(),
            data_fim=datetime.strptime(data_str, "%Y-%m-%d").date(),
            carga_horaria=int(input("Carga Horária: ")),
            Local_idLocal=novo_local.idLocal,
            Coletivo_nome=col.nome,
            CategoriaEvento_idCategoria=1
        )
        session.add(novo_evento); session.flush()

        # Organizador
        cargo = input("Seu cargo neste evento: ")
        # Atenção ao nome da coluna codEveno (conforme seu script original)
        novo_org = Organizador(cargo=cargo, Pessoa_cpf=usuario_logado.cpf, Evento_codEveno=novo_evento.codEvento)
        session.add(novo_org)

        # AUTOMAÇÃO: Inscrição automática do criador no evento
        nova_ins = Inscricao(data=date.today(), status="Organizador", 
                             Pessoa_cpf=usuario_logado.cpf, Evento_codEvento=novo_evento.codEvento)
        session.add(nova_ins)

        session.commit()
        print(f"\n✅ SUCESSO! Evento '{nome_ev}' criado e você foi inscrito automaticamente.")
    except Exception as e:
        session.rollback(); print(f"❌ Erro ao cadastrar evento: {e}")
    finally:
        session.close(); input("\nPressione Enter para continuar...")

def excluir_evento_organizador(usuario_logado):
    session = SessionLocal()
    print("\n--- MEUS EVENTOS ---")
    try:
        # CORREÇÃO: Mudamos 'organizador_nome' para 'organizador'
        query = text("SELECT id, nome_evento FROM view_eventos_ativos WHERE organizador = :nome")
        meus_eventos = session.execute(query, {"nome": usuario_logado.nome}).fetchall()
        
        if not meus_eventos:
            print("Você não organiza nenhum evento.")
            return

        for ev in meus_eventos:
            print(f"ID: {ev[0]} | Evento: {ev[1]}")

        cod = input("\nDigite o ID do evento para DELETAR: ")
        
        # Verificação de segurança antes de deletar
        if input("Confirme sua SENHA: ") == usuario_logado.senha:
            # Ordem de exclusão para evitar erro de Foreign Key
            session.execute(text(f"DELETE FROM `Inscrição` WHERE Evento_codEvento = {cod}"))
            session.execute(text(f"DELETE FROM Organizador WHERE Evento_codEveno = {cod}"))
            session.execute(text(f"DELETE FROM Evento WHERE codEvento = {cod}"))
            
            session.commit()
            print("✅ Evento removido com sucesso!")
        else:
            print("❌ Senha incorreta. Operação cancelada.")
            
    except Exception as e:
        session.rollback()
        print(f"❌ Erro ao excluir: {e}")
    finally:
        session.close()
        input("Pressione Enter...")