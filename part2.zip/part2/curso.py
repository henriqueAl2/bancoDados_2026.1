from models import Curso

def cadastrar_novo_curso(session, curso_nome):
    print(f"\nCurso não cadastrado: {curso_nome}")
    print(f"O curso '{curso_nome}' não foi encontrado no sistema.")
    print("Por favor, preencha os dados do curso:")
    
    ca = input("Centro Acadêmico: ")
    atletica = input("Atlética: ")
    dept = input("Departamento Responsável: ")
    sigla = input("Sigla do Curso: ")

    if not all([ca, atletica, dept, sigla]):
        print(" Erro: Todos os dados do curso devem ser preenchidos!")
        return None

    novo_curso = Curso(
        nome=curso_nome,
        centro_academico=ca,
        atletica=atletica,
        departamento_responsalvel=dept,
        sigla=sigla
    )
    
    session.add(novo_curso)
    session.flush() # Importante para gerar o ID antes do commit final
    print(f"Curso '{curso_nome}' preparado para salvamento!")
    return novo_curso