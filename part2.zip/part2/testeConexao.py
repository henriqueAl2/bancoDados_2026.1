from database import SessionLocal, engine
from models import Curso

def teste_insercao_direta():
    print("Tentando inserir dado de teste...")
    db = SessionLocal()
    try:
        novo = Curso(nome="Curso de Teste", sigla="TESTE")
        db.add(novo)
        db.commit()
        print("O Python diz que gravou com sucesso!")
        
        # Agora tenta ler de volta imediatamente
        verificar = db.query(Curso).filter(Curso.nome == "Curso de Teste").first()
        if verificar:
            print(f"Confirmado: O dado foi lido do banco! ID: {verificar.idCurso}")
        else:
            print("Erro: O dado foi gravado mas nao foi encontrado na busca.")
            
    except Exception as e:
        print(f"Erro na gravacao: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    teste_insercao_direta()