import os
from database import SessionLocal
from models import Inscricao, Evento
from datetime import date

def realizar_inscricao_automatica(usuario_logado):
    """
    Solicita o ID do evento e exige a senha do usuário para confirmar.
    """
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"--- CONFIRMAÇÃO DE INSCRIÇÃO ---")
    print(f"Usuário: {usuario_logado.nome}")
    print("-" * 40)

    session = SessionLocal()
    try:
        # 1. Solicita o ID do Evento
        cod_evento = input("Digite o ID do Evento em que deseja se inscrever: ")
        
        # Valida se o evento existe
        evento = session.query(Evento).filter_by(codEvento=cod_evento).first()
        if not evento:
            print("Erro: Evento não encontrado!")
            return

        # 2. Verifica se já existe uma inscrição para evitar duplicidade
        existente = session.query(Inscricao).filter_by(
            Pessoa_cpf=usuario_logado.cpf, 
            Evento_codEvento=cod_evento
        ).first()

        if existente:
            print(f" Atenção: Você já está inscrito no evento '{evento.nome}'.")
            return

        # 3. AUTOMAÇÃO DE SEGURANÇA: Solicita a senha para confirmar
        print(f"\nVocê está se inscrevendo em: {evento.nome}")
        senha_confirmacao = input("Para confirmar sua inscrição, digite sua SENHA: ")

        if senha_confirmacao == usuario_logado.senha:
            # 4. Se a senha coincidir, realiza a gravação no banco
            nova_insc = Inscricao(
                data=date.today(),
                status="Confirmada",
                Pessoa_cpf=usuario_logado.cpf,
                Evento_codEvento=cod_evento
            )
            session.add(nova_insc)
            session.commit()
            print(f"\nSUCESSO! Inscrição confirmada para o evento '{evento.nome}'.")
        else:
            print("\nErro: Senha incorreta. A inscrição foi cancelada.")

    except Exception as e:
        session.rollback()
        print(f"Erro ao processar inscrição: {e}")
    finally:
        session.close()
        input("\nPressione Enter para continuar...")