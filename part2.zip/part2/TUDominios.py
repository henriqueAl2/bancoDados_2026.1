import unittest
import dominios

class TestDominio(unittest.TestCase):

    def test_validar_nome(self):
        self.assertTrue(dominios.validar_nome("Joao Silva"))
        self.assertFalse(dominios.validar_nome("Nome Muito Grande Passa De Vinte e Cinco Letras"))

    def test_validar_cpf(self):
        self.assertTrue(dominios.validar_cpf("12345678901"))
        self.assertFalse(dominios.validar_cpf("123.456.789-01")) 
        self.assertFalse(dominios.validar_cpf("12345")) 

    def test_validar_email(self):
        self.assertTrue(dominios.validar_email("teste@gmail.com"))
        self.assertFalse(dominios.validar_email("teste@gmail")) 
        self.assertFalse(dominios.validar_email("teste.gmail.com"))

    def test_validar_telefone(self):
        self.assertTrue(dominios.validar_telefone("11988887777"))
        self.assertFalse(dominios.validar_telefone("988887777"))
        self.assertFalse(dominios.validar_telefone("abc1198888"))

    def test_validar_data(self):
        self.assertTrue(dominios.validar_data("10/05/2024"))
        self.assertFalse(dominios.validar_data("10-05-2024")) 
        self.assertFalse(dominios.validar_data("aa/bb/cccc")) 

    def test_validar_descricao(self):
        self.assertTrue(dominios.validar_descricao("Uma descrição curta."))
        texto_longo = "a" * 256
        self.assertFalse(dominios.validar_descricao(texto_longo))

if __name__ == '__main__':
    unittest.main()